#die klassen für objekte sind in einer anderen datei, damit esw übersichtlicher ist
import pygame
import os
from einstellungen import feld_pixel

#es ist besser, bilder einmal am anfang der datei zu laden und nicht für jedes objekt in einer klasse einzeln
slowness_potionImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "slowness_potion.png")),(feld_pixel,feld_pixel))
speed_potionImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien","speed_potion.png")),(feld_pixel,feld_pixel))
bombe_objektImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien","bombe_objekt.png")),(feld_pixel,feld_pixel))


class bombe_objekt(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = bombe_objektImg
        self.pos = pos
        self.rect = self.image.get_rect(topleft = pos)  #get rekt du kek

    def delete(self):
        self.kill()

class slowness_potion(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = slowness_potionImg
        self.pos = pos
        self.rect = self.image.get_rect(topleft = pos)

    def delete(self):
        self.kill()

class speed_potion(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = speed_potionImg
        self.pos = pos
        self.rect = self.image.get_rect(topleft = pos)

    def delete(self):
        self.kill()

