import pygame
from einstellungen import *
import os
from objekte import * 
import random

bildImg = pygame.transform.scale(pygame.image.load((os.path.join("dateien", "bild.png"))),(feld_pixel * 14, feld_pixel * 12))
leerImg = pygame.image.load((os.path.join("dateien", "leer.png")))
nichtsImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien","nichts.png")),(feld_pixel, feld_pixel))
borderImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "border.png")),(feld_pixel,feld_pixel))
sprengbaresImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "sprengbares.png")),(feld_pixel, feld_pixel))
leerImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "leer.png")),(feld_pixel, feld_pixel))
wegraeumbaresImg = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "wegräumbares.png")),(feld_pixel, feld_pixel))

alien1Img = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien1.png"))),(feld_pixel,feld_pixel))
alien1Img_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien1_hit.png"))),(feld_pixel,feld_pixel))

alien2Img_unten = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_unten.png"))),(feld_pixel,feld_pixel))
alien2Img_rechts = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_rechts.png"))),(feld_pixel,feld_pixel))
alien2Img_oben = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_oben.png"))),(feld_pixel,feld_pixel))
alien2Img_links = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_links.png"))),(feld_pixel,feld_pixel))
alien2Img_unten_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_unten_hit.png"))),(feld_pixel,feld_pixel))
alien2Img_rechts_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_rechts_hit.png"))),(feld_pixel,feld_pixel))
alien2Img_oben_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_oben_hit.png"))),(feld_pixel,feld_pixel))
alien2Img_links_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien2_links_hit.png"))),(feld_pixel,feld_pixel))

alien3Img = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien3.png"))),(feld_pixel-3,feld_pixel-3))
alien3Img_hit = pygame.transform.scale(pygame.image.load((os.path.join("dateien","alien3_hit.png"))),(feld_pixel-3,feld_pixel-3))
#hier fangen die klassen für die Felder an

class border(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = borderImg
        self.image = pygame.transform.scale(self.image, (feld_pixel, feld_pixel),)
        self.rect = self.image.get_rect(topleft = pos)
        self.type = "grenzfeld"


class sprengbares(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = sprengbaresImg
        self.rect = self.image.get_rect(topleft = pos)
        self.pos = pos
        self.type = "sprengbares"

    def delete(self):
        self.replace(random.randint(0,100))
        self.kill()

    def replace(self,nummer):   #wichtige sachen
        if nummer >= 95:
            slowness_potion(self.pos,[gutereSprites,slownessSprites])
        if nummer >= 10 and nummer < 20:
            speed_potion(self.pos, [gutereSprites,speedSprites])
        if nummer >= 0 and nummer < 8:
            bombe_objekt(self.pos,[gutereSprites,bombenobjekteSprites])


class spawnfeld(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "spawn.png")),(feld_pixel,feld_pixel))
        self.rect = self.image.get_rect(topleft = pos)
        self.type = "spawnfeld"


class wegraeumbares(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = wegraeumbaresImg
        self.rect = self.image.get_rect(topleft = pos)
        self.type = "wegraeumbares"

    def delete(self):
        self.kill()