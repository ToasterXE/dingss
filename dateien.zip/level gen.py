from einstellungen import *
from level_gen_elemente import *
import random
from level import Level


Liste = [
[ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,],
[ 1, 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,],
[ 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,],
]


def space(width, height, x, y):
    i = 0
    while i < height:
        e = 0
        while e < width:
            if Liste[x + e][y + i] == 0:
                e += 1
            else:
                return False
        i += 1
    return True


def gen_sprengbares():
    for starty, zeile in enumerate(Liste):
        for startx, spalte in enumerate(zeile):
            if Liste[starty][startx] == 0 or Liste[starty][startx] == 9:
                chance = 14
                if startx > 3 and starty > 3:
                    i = 0
                    while i < 3:
                        e = 0
                        while e < 3:
                            if Liste[starty - e][startx - i] == 2:
                                chance /= 2
                            e += 1
                        i += 1
                if int(chance) < 1:
                    chance = 1
                if random.randint(1,int(chance)) == 1:
                    el = element4(Liste, starty, startx)
                    el.gen()


def gen_copy(c_Liste):
    c_Liste[random.randint(0,len(c_Liste))][random.randint(0,len((c_Liste[0])))] = 20
    zahl = random.randint(1,10)
    while not zahl == 1:
        c_Liste[random.randint(0,len(c_Liste))][random.randint(0,len((c_Liste[0])))] = 20
        zahl = random.randint(1,10)
    print (c_Liste)

def gen_map():
    copy_Liste = Liste.copy()
    gen_copy(copy_Liste)
    for starty, zeile in enumerate(Liste):
        for startx, spalte in enumerate(zeile):
            if Liste[starty][startx] == 0:
                if random.randint(0,10) == 1:

                    el = element3(Liste, starty, startx)
                    if startx + el.width <= len(zeile) and starty + el.height <= len(Liste):
                        if space(el.width, el.height, starty - 1, startx - 1) == True:
                            el.gen()

                elif random.randint(0,0) == 1:
                    el = element2(Liste, starty, startx)
                    if startx + el.width <= len(zeile) and starty + el.height <= len(Liste):
                        if space(el.width, el.height, starty, startx) == True:
                            el.gen()
    gen_sprengbares()

#print (Liste)
gen_map()
Level1 = Level(Liste)
clock = pygame.time.Clock()
def Levelrun():
    run = True
    while run:
        clock.tick(60)
        window.fill((20,20,20)) 
        Level1.run()
        pygame.display.update()

        for event in pygame.event.get():

        
            if event.type == pygame.QUIT:
                pygame.quit()
                run = False
Levelrun()