import pygame
import os
from maps import kachelgröße


speed = 2
Horizontalzuletzt = "keine" 
Vertikalzuletzt = "keine"
zuletzt = "keine"



class Player(pygame.sprite.Sprite):
    def __init__(self,pos,groups,hindernisse):
        super().__init__(groups)
        self.vorneImg = pygame.image.load((os.path.join("dateien", "player_vorne.png")))
        self.obenImg = pygame.image.load((os.path.join("dateien", "player_oben.png")))
        self.untenImg = pygame.image.load((os.path.join("dateien", "player_unten.png")))
        self.rechtsImg = pygame.image.load((os.path.join("dateien", "player_rechts.png")))
        self.linksImg = pygame.image.load((os.path.join("dateien", "player_links.png")))
        self.image = self.vorneImg
        self.rect = self.image.get_rect(topleft = pos)
        self.blickrichtung = pygame.math.Vector2()
        self.hindernisse = hindernisse


    def player_movement(self):
        keys_pressed = pygame.key.get_pressed()
        global i, zuletzt, Vertikalzuletzt, Horizontalzuletzt


        if keys_pressed[pygame.K_w]:
            self.blickrichtung.x = 0
            self.blickrichtung.y = -1
            Vertikalzuletzt = "w"
            zuletzt = "w"
            self.image = self.obenImg


        elif keys_pressed[pygame.K_s]:
            self.blickrichtung.x = 0    
            self.blickrichtung.y = 1
            Vertikalzuletzt = "s"
            zuletzt = "s"
            self.image = self.untenImg


        elif keys_pressed[pygame.K_a]:
            self.blickrichtung.x = -1
            self.blickrichtung.y = 0
            Horizontalzuletzt = "a"
            zuletzt = "a"
            self.image = self.linksImg


        elif keys_pressed[pygame.K_d]:
            self.blickrichtung.x = 1
            self.blickrichtung.y = 0
            Horizontalzuletzt = "d"
            zuletzt = "d"
            self.image = self.rechtsImg


        else:
            self.blickrichtung.x = 0
            self.blickrichtung.y = 0            
            self.image = self.vorneImg
        

        if self.rect.top % kachelgröße == 0:
            pass
        
        else:
            if Vertikalzuletzt == "w":
                self.image = self.obenImg
                self.rect.top -= speed
            if Vertikalzuletzt == "s":
                self.rect.top += speed
                self.image = self.untenImg
        
        if self.rect.left % kachelgröße == 0:
            pass
        
        else:    
            if Horizontalzuletzt == "d":
                self.rect.left += speed
                self.image = self.rechtsImg
            if Horizontalzuletzt == "a":
                self.rect.left -= speed
                self.image = self.linksImg

        
        self.rect.topleft += (self.blickrichtung * speed)


        
        for hinderniss in self.hindernisse:
        

            if hinderniss.rect.colliderect(self.rect):

                if zuletzt == "w":
                    self.rect.top += speed
                if zuletzt == "s":
                    self.rect.top -= speed
                if zuletzt == "d":
                    self.rect.left -= speed
                if zuletzt == "a":
                    self.rect.left += speed

        
    def update(self):
        self.player_movement()
        
        
        
