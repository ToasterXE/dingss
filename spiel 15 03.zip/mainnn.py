import pygame,sys
import os
from maps import *
from level import *

pygame.font.init()


window = pygame.display.set_mode((windowBreite, windowHöhe))
pygame.display.set_caption("dingss")
arial20 = pygame.font.SysFont("Arial", 20)
 

def button(name, links, oben, breite, höhe, color, color_hover):
    buttonSchrift = arial20.render(name, True, (230, 230, 230))
    buttonSchrift_rect = buttonSchrift.get_rect(center = (links + breite / 2, oben + höhe / 2))
    
    name = pygame.Rect(links, oben, breite, höhe)
    mausPos = pygame.mouse.get_pos()
    
    pygame.draw.rect(window, color, name)
    window.blit(buttonSchrift, buttonSchrift_rect)

    if name.collidepoint(mausPos):
        pygame.draw.rect(window, color_hover, name)
        window.blit(buttonSchrift, buttonSchrift_rect)
        if pygame.mouse.get_pressed()[0] == True:
            return True


clock = pygame.time.Clock()
level1 = Level(Level1_map)
level2 = Level(Level2_map)
level3 = Level(Level3_map)



def main():
    run = True
    while run:
        clock.tick(60)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
            if event.type ==  pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    level3.dings()
        window.fill((20,20,20))
        
        level3.run(Level3_map)
        #level1.run()
        #level2.run(Level2_map)


        pygame.display.update()

main()