import pygame, os
from maps import *
from player import Player

class border(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = pygame.image.load((os.path.join("dateien", "border.png")))
        self.image = pygame.transform.scale(self.image, (kachelgröße, kachelgröße),)
        self.rect = self.image.get_rect(topleft = pos)



class sprengbares(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = pygame.transform.scale(pygame.image.load((os.path.join("dateien", "sprengbares.png"))),(kachelgröße, kachelgröße))
        self.rect = self.image.get_rect(topleft = pos)



class leer(pygame.sprite.Sprite):
    def __init__(self,pos,groups,img):
        super().__init__(groups)
        self.image = img
        self.rect = self.image.get_rect(topleft = pos)



class spawnfeld(pygame.sprite.Sprite):
    def __init__(self,pos,groups):
        super().__init__(groups)
        self.image = pygame.image.load((os.path.join("dateien", "spawn.png")))
        self.rect = self.image.get_rect(topleft = pos)



class wegräumbares(pygame.sprite.Sprite):
    def __init__(self,pos,groups,img):
        super().__init__(groups)
        self.image = img
        self.rect = self.image.get_rect(topleft = pos)
    def delete(self):
        self.kill()



class bombe(pygame.sprite.Sprite):
    def __init__(self, groups, pos):
        super().__init__(groups)
        self.explosionsImg1 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "bombe1.png")),(kachelgröße, kachelgröße))
        self.explosionsImg2 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "bombe2.png")),(kachelgröße, kachelgröße))
        self.explosionsImg3 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "bombe3.png")),(kachelgröße, kachelgröße))
        self.explosionsImg4 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "bombe4.png")),(kachelgröße, kachelgröße))
        self.explosionsImg5 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "explosion1.png")),(kachelgröße, kachelgröße))
        self.explosionsImg6 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "explosion2.png")),(kachelgröße, kachelgröße))
        self.explosionsImg7 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "explosion3.png")),(kachelgröße, kachelgröße))
        self.explosionsImg8 = pygame.transform.scale(pygame.image.load(os.path.join("dateien", "explosion4.png")),(kachelgröße, kachelgröße))
        self.explosionsSprites = []
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg1)
        self.explosionsSprites.append(self.explosionsImg2)
        self.explosionsSprites.append(self.explosionsImg3)
        self.explosionsSprites.append(self.explosionsImg4)
        self.explosionsSprites.append(self.explosionsImg5)
        self.explosionsSprites.append(self.explosionsImg6)
        self.explosionsSprites.append(self.explosionsImg7)
        self.explosionsSprites.append(self.explosionsImg8)
        self.counter = 0
        self.image = self.explosionsSprites[self.counter]
        self.rect = self.image.get_rect(topleft = pos)

    def explode(self):
        self.exploding = True

    def update(self):
        if self.exploding == True:
            self.counter += 0.2
        if self.counter >= len(self.explosionsSprites):
            self.counter = 0
            self.kill()
        self.image = self.explosionsSprites[int(self.counter)]
        


class Level:
    def __init__(self, map):
        self.mapBreite = 0
        self.mapHöhe = 0
        self.explosionSprite_count = 0
        self.display_surface = pygame.display.get_surface()
        self.sichtbareSprites = pygame.sprite.Group()
        self.andereSprites = pygame.sprite.Group()
        self.updateSprites = pygame.sprite.Group()
        self.bessereSprites = pygame.sprite.Group()
        self.gutereSprites = pygame.sprite.Group()
        self.camAbstand = pygame.math.Vector2()
        self.leerImg = pygame.transform.scale(pygame.image.load((os.path.join("dateien", "leer.png"))),(kachelgröße, kachelgröße))
        self.wegräumbaresImg = pygame.image.load((os.path.join("dateien", "wegräumbares.png")))
        
        self.create_map(map)



    def create_map(self, map):
        for spalte_index, spalte in enumerate(map):
            for zeile_index, spalte in enumerate(spalte):
                x = zeile_index * kachelgröße
                y = spalte_index * kachelgröße


                if spalte == "e":
                    border((x,y),[self.sichtbareSprites, self.andereSprites])


#                if spalte == " ":
 #                   leer((x,y), [self.sichtbareSprites], self.leerImg)


                if spalte == "p":
                    self.Player = Player((x,y),[self.bessereSprites], self.andereSprites)
                    spawnfeld((x,y),[self.sichtbareSprites])

                
                if spalte == "s":
                    sprengbares((x,y),[self.sichtbareSprites, self.updateSprites, self.andereSprites])


                if spalte == "d":
                    pass


                if spalte == "w":
                    wegräumbares((x,y), [self.sichtbareSprites, self.updateSprites], self.wegräumbaresImg)
                

                self.mapBreite += 32    
            self.mapHöhe += 32
        self.mapBreite = self.mapBreite // (self.mapHöhe / 32)       



    def update_map(self,map):
        for wegräumbares in self.updateSprites:
            if self.Player.rect.colliderect(wegräumbares.rect):
                wegräumbares.delete()
      

    def draw(self, player):
        for sprite in self.sichtbareSprites:
            self.camAbstand.y = (player.rect.top - 225) 
            self.camAbstand.x = (player.rect.left - 400) 


            if self.Player.rect.top <= 224:
                self.camAbstand.y = 0
            

            if self.Player.rect.top >= self.mapHöhe - 224:
                self.camAbstand.y = self.mapHöhe - 448
            

            if self.Player.rect.left <= 400:
                self.camAbstand.x = 0
            

            if self.Player.rect.left >= self.mapBreite - 399:
                self.camAbstand.x = self.mapBreite - 798


            self.display_surface.blit(sprite.image, (sprite.rect.topleft - self.camAbstand))

        for sprite in self.gutereSprites:
            self.display_surface.blit(sprite.image, sprite.rect.topleft - self.camAbstand)
            
            

        for sprite in self.bessereSprites:
            self.display_surface.blit(sprite.image, sprite.rect.topleft - self.camAbstand)            



    def dings(self):    
        pos = pygame.math.Vector2((self.Player.rect.left - self.Player.rect.left % kachelgröße, self.Player.rect.top - self.Player.rect.top % kachelgröße))
        bombe1 = bombe([self.gutereSprites],pos)
        bombe1.explode()


    def run(self,map):
        self.sichtbareSprites.update()
        self.bessereSprites.update()
        self.gutereSprites.update()
        self.update_map(map)
        self.draw(self.Player)
        
        