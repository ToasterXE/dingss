#hier werden variablen für wahrscheinlichkeiten von sachen definiert, damit man leicht auf diese zugreifen kann
bListemin = 20
bListemax = 20

hListemin = 20
hListemax = 20

sdingscmin = 1
sdingscmax = 5
